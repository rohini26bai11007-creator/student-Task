"""Tests for the Student Task and To-Do Manager using Python's unittest."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from task_manager import TaskManager
from status_manager import StatusManager
from category_manager import CategoryManager
from report_manager import ReportManager
from validators import clean_text, positive_integer


class TaskProjectTests(unittest.TestCase):
    def setUp(self):
        self.manager = TaskManager()
        self.first = self.manager.add_task("Read chapter", "Python", "Study", "Friday")
        self.second = self.manager.add_task("Submit lab", "Python", "Assignment", "Monday")

    def test_add_and_find_task(self):
        self.assertEqual(self.manager.find_task(1), self.first)
        self.assertIsNone(self.manager.find_task(99))

    def test_search_is_case_insensitive(self):
        self.assertEqual(self.manager.search_tasks("CHAPTER"), [self.first])

    def test_mark_and_filter_status(self):
        statuses = StatusManager()
        self.assertTrue(statuses.mark_completed(self.first))
        self.assertEqual(statuses.get_completed(self.manager.get_all_tasks()), [self.first])
        self.assertEqual(statuses.get_pending(self.manager.get_all_tasks()), [self.second])

    def test_delete_task(self):
        self.assertTrue(self.manager.delete_task(1))
        self.assertFalse(self.manager.delete_task(1))
        self.assertEqual(len(self.manager.get_all_tasks()), 1)

    def test_group_and_report(self):
        groups = CategoryManager().organize_by_subject(self.manager.get_all_tasks())
        self.assertEqual(len(groups["Python"]), 2)
        report = ReportManager().make_report(self.manager.get_all_tasks())
        self.assertEqual(report, {"total": 2, "completed": 0, "pending": 2})

    def test_validators(self):
        self.assertEqual(clean_text("  Python ", "Subject"), "Python")
        self.assertEqual(positive_integer("3"), 3)
        with self.assertRaises(ValueError):
            clean_text("  ", "Title")
        with self.assertRaises(ValueError):
            positive_integer("0")


if __name__ == "__main__":
    unittest.main()
